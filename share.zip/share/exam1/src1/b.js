console.log("BBB")
export const a = "BBB";
export const fn = () => {
  console.log('this is module b ');
}