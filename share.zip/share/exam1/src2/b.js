import * as c from './c'

console.log("BBB")