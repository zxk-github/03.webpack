console.log("DDD")
export const d = "DDD";