import * as c from './c';
import * as d from './d';
console.log(c.c)
console.log("AAA")

