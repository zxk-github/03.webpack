console.log("CCC")
export const c = "CCC";