import * as b from './b';
import * as c from './c';
console.log(b.fn);
console.log(c.fn)
console.log("AAA")

