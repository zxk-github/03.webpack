console.log("CCC")
export const a = "CCC";
export const fn = () => {
  console.log('this is module c ');
}